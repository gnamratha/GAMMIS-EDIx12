package org.ediX12;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;


@RestController
@RequestMapping("/api")
public class EdiController {
    @Autowired
    private EdiConversionService ediConversionService;

    @PostMapping("/convertJsonToEdi")
    public ResponseEntity<String> convertJsonToEdi(@RequestBody String jsonString) {
        //System.out.println("Received JSON: " + jsonString);
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.readTree(jsonString);

            // Condition to determine whether it's 837P or 270
            String st01Value = jsonNode.path("ST").path("ST01").asText();
            boolean is837P = "837".equals(st01Value);
            boolean is270 = "270".equals(st01Value);

            ResponseEntity<String> ediResponse;
            if (is837P) {
                ediResponse = ediConversionService.convertJsonToEdi837P(jsonString);
            } else if (is270) {
                ediResponse = ediConversionService.convertJsonToEdi270(jsonString);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid value for ST01");
            }
           // System.out.println("Response EDI: " + ediResponse.getBody());
            return ediResponse; // Return the ResponseEntity directly
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error converting JSON to EDI");
        }
    }
}