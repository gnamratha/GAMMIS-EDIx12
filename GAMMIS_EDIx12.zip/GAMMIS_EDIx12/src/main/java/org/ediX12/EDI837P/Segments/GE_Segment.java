package org.ediX12.EDI837P.Segments;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GE_Segment {

    @JsonProperty("GE00")
    private String GE00;
    @JsonProperty("GE01")
    private String GE01;
    @JsonProperty("GE02")
    private String GE02;

}
