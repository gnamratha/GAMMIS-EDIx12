package org.ediX12.EDI837P.Segments;

import com.fasterxml.jackson.annotation.JsonProperty;

public class IEA_Segment {
        @JsonProperty("IEA0")
        private String iea00;
        @JsonProperty("IEA01")
        private String iea01;
        @JsonProperty("IEA02")
        private String iea02;
}
