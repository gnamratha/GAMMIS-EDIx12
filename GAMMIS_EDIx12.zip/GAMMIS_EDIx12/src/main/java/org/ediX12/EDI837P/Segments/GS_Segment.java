package org.ediX12.EDI837P.Segments;

import com.fasterxml.jackson.annotation.JsonProperty;
public class GS_Segment {

        @JsonProperty("GS01")
        private String GS01;
        @JsonProperty("GS02")
        private String GS02;
        @JsonProperty("GS03")
        private String GS03;
        @JsonProperty("GS04")
        private String GS04;
        @JsonProperty("GS05")
        private String GS05;
        @JsonProperty("GS06")
        private String GS06;
        @JsonProperty("GS07")
        private String GS07;
        @JsonProperty("GS08")
        private String GS08;


    public String getGS01() {
        return GS01;
    }

    public void setGS01(String GS01) {
        this.GS01 = GS01;
    }

    public String getGS02() {
        return GS02;
    }

    public void setGS02(String GS02) {
        this.GS02 = GS02;
    }

    public String getGS03() {
        return GS03;
    }

    public void setGS03(String GS03) {
        this.GS03 = GS03;
    }

    public String getGS04() {
        return GS04;
    }

    public void setGS04(String GS04) {
        this.GS04 = GS04;
    }

    public String getGS05() {
        return GS05;
    }

    public void setGS05(String GS05) {
        this.GS05 = GS05;
    }

    public String getGS06() {
        return GS06;
    }

    public void setGS06(String GS06) {
        this.GS06 = GS06;
    }

    public String getGS07() {
        return GS07;
    }

    public void setGS07(String GS07) {
        this.GS07 = GS07;
    }

    public String getGS08() {
        return GS08;
    }
    public void setGS08(String GS08) {
        this.GS08 = GS08;
    }
}

