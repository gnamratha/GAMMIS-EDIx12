package org.ediX12.EDI837P.Segments;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SE_Segment {
    @JsonProperty("SE00")
    private String SE00;
    @JsonProperty("SE01")
    private String SE01;
    @JsonProperty("SE02")
    private String SE02;
}
